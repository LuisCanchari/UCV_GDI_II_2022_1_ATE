
 
if db_id('db_convivir') is not null
   drop database db_convivir;
go

create database db_convivir;
go

use db_convivir;
go

if object_id('documentos') is not null
	drop table documentos;

create table documentos(
	id int not null IDENTITY,
	tipo varchar(10) not null,
	numero varchar(9) not null,
	fecha date,
	descripcion varchar(MAX), 
	total decimal(8,2), 
	constraint PK_documentos Primary key (id)
);

go

--CONFIGURAR FORMATO DE FECHA
set dateformat dmy;
go

--INSERTAR DATOS
insert into documentos (tipo, numero, fecha, descripcion, total) values
('boleta','001', '24/06/2022','Adquisicion de Materiales de limpieza', 200.00 );

insert into documentos (tipo, numero, fecha, descripcion, total) values
('boleta', '002', '24/06/2022','Pago se servicio de limpieza', 900.00 );

insert into documentos (tipo, numero, fecha, descripcion, total) values
('factura', '001-200', '24/01/2022','Adquisicion de bomba de agua', 2900.00 );

insert into documentos (tipo, numero, fecha, descripcion, total) values
('factura', '001-500', '04/02/2022','Adquisicion de 4 camaras de video', 1900.00 );

insert into documentos (tipo, numero, fecha, descripcion, total) values
('recibo' , '005', '25/03/2022','Pago por se servicio de jardineria', 200.00 );

insert into documentos (tipo, numero, fecha, descripcion, total) values
('recibo', '006', '01/04/2022','Pago por desechos de escombros', 150.00 );

insert into documentos (tipo, numero, fecha, descripcion, total) values
('ticket', '000020', '24/05/2022','Compra de desinfectantes', 50.00 );

insert into documentos (tipo, numero, fecha, descripcion, total) values
('ticket', '000022', '25/06/2022','Servicio de fotocopiado', 30.00 );

go

--CREAR PROCEDIMIENTO ALMACENADO
if object_id('usp_documentos_lista') is not null
  drop procedure usp_documentos_lista;

go

CREATE PROCEDURE usp_documentos_lista
AS
BEGIN 
	SELECT id, tipo, numero, fecha, descripcion, total
	FROM documentos;
END 

go

if object_id('usp_documentos_item') is not null
  drop procedure usp_documentos_item;

go

CREATE PROCEDURE usp_documentos_item
@id int
AS
BEGIN 
	SELECT TOP 1 id, tipo, numero, fecha, descripcion, total
	FROM documentos
	WHERE id = @id;
END

go

if object_id('usp_documentos_insert') is not null
  drop procedure usp_documentos_insert;

go

CREATE PROCEDURE usp_documentos_insert
 @tipo nvarchar(10), 
 @numero nvarchar(9), 
 @fecha date, 
 @descripcion nvarchar(MAX), 
 @total decimal 
AS
BEGIN 
	INSERT INTO documentos (tipo, numero, fecha, descripcion, total)
	VALUES (@tipo, @numero, @fecha, @descripcion, @total);
END 
go

if object_id('usp_documentos_edit') is not null
  drop procedure usp_documentos_edit;

go

CREATE PROCEDURE usp_documentos_edit
 @id int,
 @tipo nvarchar(10), 
 @numero nvarchar(9), 
 @fecha date, 
 @descripcion nvarchar(MAX), 
 @total decimal 
AS
BEGIN 
	UPDATE documentos 
	SET 
	tipo = @tipo, 
	numero=@numero, 
	fecha=@fecha, 
	descripcion=@descripcion, 
	total=@total
	WHERE id = @id;
END
go

if object_id('usp_documentos_del') is not null
  drop procedure usp_documentos_del;

go


CREATE PROCEDURE usp_documentos_del
 @id int
 
AS
BEGIN 
	DELETE FROM documentos
	WHERE id = @id;
END
go
